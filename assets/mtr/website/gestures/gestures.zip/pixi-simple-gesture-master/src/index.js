import pinchable from './gestures/pinch'
import panable from './gestures/pan'
import tappable from './gestures/tap'

export default {
  pinchable,
  panable,
  tappable
}
