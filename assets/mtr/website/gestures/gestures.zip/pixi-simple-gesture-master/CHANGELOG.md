### 0.3.0

- Add Inertia Mode

### 0.2.0

- Add 'simpletap'.
- Modify 'panstart' emit timing. Now 'panstart' is emitted after the mouse / touch actually moved.
